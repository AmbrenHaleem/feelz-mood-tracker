import { Text, View } from 'react-native';
import Form from '../../../Form';

export default function AddMood({navigation}){
    return (
        // <Text> Add Mood</Text>
        <View>
            <Form> </Form>
        </View>
    )
}