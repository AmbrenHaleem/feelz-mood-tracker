export const appName = 'FEELZ'
export const primaryColor = '#2A6194'
export const secondaryColor = '#FEFBFF'
export const greyColor = "#666"